from django.shortcuts import render
from django.http import  HttpResponse
# Create your views here.
from .models import Department,Student,Stu_detail,Course
def test(request):
    # # 往department表里面插入数据
    # d1 = Department(d_name='文学院')
    # d1.save()
    # # 往student数据表里插入数据
    # s1 = Student(s_name='凯西',dept_id=1)
    # s1.save()
    # s2 = Student(s_name='小红')
    # s2.dept = d1
    # s2.save()
    # s1 = Student.objects.get(s_id=1)  # 学生的一个实例对象
    # d1 = Department.objects.get(d_id=1)  # 学院的一个实例对象
    # print(s1)   # 一个学生的实例
    # print(s1.s_name)  # 学生的姓名
    # print(s1.dept_id)   # 学生的所属学院的id
    # print(s1.dept)   # 学生的所属学院,模型类定义的属性
    # print(d1)      # 一个学院的实例
    # print(d1.d_name)  # 学院的名字
    # # 反向查的时候, 模型类小写_set
    # print(d1.student_set)  # 反向的时候的一种管理器,里面包含了方法
    # print(d1.student_set.all())  # .all拿到数据
    # d2 = Department.objects.get(d_id=2)
    # # add()方法  修改  数据已经存在  一对多,多对多
    # d2.student_set.add(s1)  # 给朱诗勇同学换一个学院
    # # creat()方法 新建数据,  一对多,多对多
    # d2.student_set.create(s_name='李易峰')
    # remove() 方法  多对多 (表约束)
    # clear() 清空
    return HttpResponse('xxxx')
from django.db.models import Count
def test22(request):
    # 插入数据
    # Department.objects.create(d_name='语言学院')
    # s1 = Student(s_name='小明',dept_id=2)
    # s1.save()
    # s2 = Student(s_name='小红')
    # department = Department.objects.get(d_id=3)
    # s2.dept = department
    # s2.save()
    # '''往详情表加数据'''
    # sdt1 =  Stu_detail(student_id=2,age=22,gender=1,city='shanghai')
    # sdt1.save()
    # '''往课程表中加数据'''
    # py = Course(c_name='python')
    # py.save()
    # java = Course(c_name='java')
    # java.save()
    ruanjian = Department.objects.get(d_id=1)  # 学院的第一条数据的实例对象
    zsy = Student.objects.get(s_id=1)  # 学生的一个实例对象
    stu_detail1 = Stu_detail.objects.get(id=1)   # 详细的一个实例对象
    python = Course.objects.get(c_id=1)   # 课程的一个实例对象
    # '''关于关联对象的访问'''
    # # 正向查就是.属性
    # # 反向的查  .类名小写_set
    # # 一对多
    # # print(zsy.dept)    # 所属的学院
    # # print(ruanjian.student_set.all())   # 软件学院的所有学生
    # # # 一对一
    # # print(stu_detail1.student)    # 一
    # # print(zsy.stu_detail)           # 一
    # # # 多对多
    # # print(python.student)   # python课程的所有学生
    # # print(zsy.course_set.all())  # 朱诗勇报名了哪些课程
    # '''表关联对象的方法'''
    # '''add(), 一对多,多对多, 数据已经存在于数据'''
    # # wen = Department.objects.get(d_id=3)
    # # wen.student_set.add(zsy)    # 数据的修改
    # # print(zsy.course_set.all())
    # # java = Course.objects.get(c_name='java')
    # # zsy.course_set.add(python,java)
    # '''creat(),数据不存在可以新建  一对多,多对多 '''
    # # wen.student_set.create(s_name='修习人生')
    # # ruanjian.student_set.create(s_name='张林林')
    # # Python课程新加人了一个新的学生,同时将信息存入了两张表里面
    # # python.student.create(s_name='邓永湘',dept_id=2)
    # # zsy.course_set.create(c_name='日语')
    # '''remove() 多对多'''
    # # python.student.remove(zsy)
    # '''clear() '''
    # # python.student.clear()

    '''多表查询'''
    # 查询学院名字为‘软件学院’的学生的信息
    # rs = Student.objects.filter(dept__d_name='软件学院')
    # 查询学生名字中包含 '小' 的学生的学院信息
    # rs = Department.objects.filter(student__s_name__contains='小')
    # # 查询学号为1的学生所有的课程
    # rs = Course.objects.filter(student__s_id=1)
    # # # 查询报了课程java的所有的学生
    # rs = Student.objects.filter(course__c_name='java')
    # # 查询报了'python'课程的的学生的所属学院的信息
    # rs = Department.objects.filter(student__course__c_name='python')

    # print(rs)
    '''分组查询'''
    # 学院分组条件
    # 一对多
    rs = Student.objects.values('dept')
    rs = Student.objects.values('dept').annotate(count=Count('dept')).values('dept_id','count')
    rs = Student.objects.values('dept').annotate(count=Count('dept')).values('dept__d_name','count')
    # 多对多
    # 课程的学生
    rs = Course.objects.all()
    rs = Course.objects.all().annotate(count=Count('student')).values('c_name','count')
    rs = Course.objects.all().annotate(count=Count('student')).values('c_id','count')
    # 学生的课程
    rs = Student.objects.all().annotate(count=Count('course')).values('s_name','count')
    print(rs)

    return HttpResponse('XXXXX')


