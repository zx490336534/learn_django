from django.db import models

# Create your models here.

class Department(models.Model):
    d_id = models.AutoField(primary_key=True)
    d_name = models.CharField(max_length=30)

    def __str__(self):
        return 'Department<d_id=%s,d_name=%s>'%(
            self.d_id,self.d_name
        )
# student.dept   学生的所属学院
# departmen.student_set   学院的学生
# 用related_name  重命令反向查询,默认的名字:类名小写_set
class Student(models.Model):
    s_id = models.AutoField(primary_key=True)
    s_name = models.CharField(max_length=30)
    dept = models.ForeignKey('Department',on_delete=models.CASCADE,
                             related_name='students')
    # dept_id
    # course = models.ManyToManyField('Course')

    def __str__(self):
        return 'Student<s_id=%s,s_name=%s,dept_id=%s>' % (
            self.s_id, self.s_name, self.dept_id
        )


class Course(models.Model):
    c_id = models.AutoField(primary_key=True)
    c_name = models.CharField(max_length=30)
    student = models.ManyToManyField('Student')
    # 帮我们自动生成关系关系
    def __str__(self):
        return 'Course<c_id=%s,c_name=%s>'%(
            self.c_id,self.c_name
        )

class Stu_detail(models.Model):
    student = models.OneToOneField('Student',on_delete=models.CASCADE)
    # student_id
    age = models.IntegerField()
    gender = models.BooleanField(default=1)
    city = models.CharField(max_length=30,null=True)

    def __str__(self):
        return 'Stu_detail<s_id=%s,age=%s,gender=%s,city=%s>'%(
            self.student,self.age,self.gender,self.city
        )
