from django.apps import AppConfig


class DbConfig(AppConfig):
    name = 'db'
