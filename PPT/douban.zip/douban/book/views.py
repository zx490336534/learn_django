from django.shortcuts import render,render_to_response
from django.http import HttpResponse
# Create your views here.
from .models import User

def add_user(request):
    # 方法一
    # taka = User(name='小泼',age=18)
    # taka.save()
    # 方法二
    # moran = User()
    # moran.name = '墨染'
    # moran.age = 18
    # moran.save()
    # 方法三
    # User.objects.create(name='句号',age=19)
    # 方法四
    # info = [('xixi',20),('haha',18)]
    # for name,age in info:
    #     User.objects.create(name=name,age=age)
    # User.objects.get_or_create(name='xiaoming',age=19)
    # User.objects.get_or_create(name='xiaohong',age=19)
    # User.objects.get_or_create(name='xiaoxin',age=19)
    return HttpResponse('添加数据成功!')

def search_user(request):
    rs = User.objects.all()  # 返回的queryset对象
    # print(rs[2])   # 索引取值  for
    # print(rs[2].name)
    # print(rs[2].age)
    # print(rs.first())
    # print(rs.last())
    # print(rs[2:5])
    # rs = User.objects.get(name='taka')   # 类实例对象,表里面的一条
    # print(rs)
    # print(rs.name)
    # print(rs.age)
    # rs = User.objects.filter(name='句号') # queryet对象
    # print(rs[0])
    # print(rs[0].name)
    # print(rs[0].age)
    # User.objects.filter(name='tuple',age=19)
    # rs = User.objects.order_by('-age','-id')
    # rs = User.objects.all().values()
    # rs = User.objects.count()
    # 查询条件
    # rs = User.objects.filter(name__exact='tuple')
    # rs = User.objects.filter(name__contains='xiao')
    # rs = User.objects.filter(age__in=[18,20])  # 18或者20
    # rs = User.objects.filter(age__range=(18,20))# 18,19,20
    # rs = User.objects.filter(age__gt=18) # 大于18
    # rs = User.objects.filter(age__lt=18) # 小于18
    # rs = User.objects.filter(note__isnull=True)
    # rs = User.objects.filter(note='NULL')
    print(rs)


    return HttpResponse('查询数据成功!')

def delete_user(request):
    # User.objects.filter(name='句号').delete()
    # User.objects.get(id=1).delete()
    return HttpResponse('删除数据成功!')


def update_user(request):
    # User.objects.filter(name='小泼').update(name='皮皮')
    # rs = User.objects.get(name='墨染')
    # rs.name = '黑炭'
    # rs.save()
    return HttpResponse('更新数据成功!')


from django.db.models import Avg,Max,Min,Sum,F,Q
from .models import F_test
def f_test(request):
    # # F_test.objects.create(name='小明',age=18)
    # xm2 = F_test.objects.get(name='小明')    # 单个实例
    # xm2 = F_test.objects.filter(name='小明')[0] # queryset
    # # # xm1.note = '我叫小明!!!!!'
    # # # xm1.save()
    # # xm2.update(note='哈哈哈')   # note是不是数据库的字段
    # xm2.note = '嘻嘻'
    # xm2.save()
    #
    # rs = User.objects.all().aggregate(Avg('age'),Max('age'),
    #                                   Min('age'),Sum('age'))
    # print(rs)
    # rs  = User.objects.all().update(age=F('age')+1)
    # 名字为xiaoming   xiaohong
    rs = User.objects.filter(Q(name='xiaoming')|Q(name='xiaohong'))
    rs = User.objects.filter(Q(name='xiaoming')&~Q(age=21))
    print(rs)
    return HttpResponse('HHHHHH')

