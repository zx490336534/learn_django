from django.db import models

# Create your models here.

class User(models.Model):
    id = models.AutoField(primary_key=True)  #可以省略
    name = models.CharField(max_length=30)
    age = models.IntegerField()
    note = models.CharField(max_length=100,null=True)
    city = models.CharField(max_length=100,default='长沙')

    def __str__(self):
        return "User<id=%s,name=%s,age=%s>"%(self.id,self.name,self.age)

# class Test11(models.Model):
#     name = models.CharField(max_length=30)
#     age = models.IntegerField()

class F_test(models.Model):
    name = models.CharField(max_length=30,unique=True)
    age = models.IntegerField()
    note = models.TextField(null=True)
    gender = models.BooleanField(default=True)
    create_time = models.DateField(auto_now_add=True)  # auto_now_add 第一次的时间,更新不修改
    update_time = models.DateTimeField(auto_now=True)  # auto_now 实时修改










