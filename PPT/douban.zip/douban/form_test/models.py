from django.db import models

# Create your models here.
class UserModel(models.Model):
    username = models.CharField(max_length=30,unique=True)
    password = models.CharField(max_length=100)
    email = models.EmailField()



# 之前用到的自定义的用户表
# 把用户表换成我们auth系统当中的 User