from django.apps import AppConfig


class FormTestConfig(AppConfig):
    name = 'form_test'
