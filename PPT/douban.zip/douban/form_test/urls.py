from django.urls import path
from . import views
# from django.conf.urls import handler404,handler500,handler403

urlpatterns = [
    path('home/',views.home,name='home'),
    path('login/',views.login_test,name='login_test'),
    path('logout/',views.logout_test,name='logout_test'),
    path('register/',views.register,name='register'),
    path('test/',views.auth_test),
        ]

# handler403 = views.permission_denied
# handler404 = views.page_not_found
# handler500 = views.page_error