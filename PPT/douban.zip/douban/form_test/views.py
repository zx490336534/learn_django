from django.shortcuts import render,redirect,reverse
from django.contrib.auth.hashers import make_password,check_password
from django.contrib.auth.models import User,Group,Permission
from django.contrib.auth import authenticate,login,logout
# Create your views here.
def home(request):
    # 显示谁登录了
    # name = 'taka'
    # x = 1+'1'
    # print(request.myuser)
    name = request.session.get('username','游客')
    return render(request,'form_test/home.html',
                  {'name':name})

# def login_test(request):
#     if request.method == 'GET':
#         return render(request,'form_test/login_test.html')
#     elif request.method == 'POST':
#         username = request.POST.get('username')
#         request.session['username'] = username    # 状态保持
#         return redirect(reverse('home'))
from .models import UserModel
from .forms import  LoginForm,RegisterFrom

def login_test(request):
    if request.method == 'GET':
        form = LoginForm()
        return render(request,'user_login/login.html',
                      context={'form':form})
    elif request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')   # 从页面来的
            print(username,password)
            user = authenticate(username=username,password=password)
            print(user)
            # user = UserModel.objects.filter(username=username)   # queryset
            if user:  # 数据库里面有没有
                # password 页面上面来的,没加密
                # user[0].password  数据库里面来的
                #   if password == user[0].password:
                # if check_password(password,user[0].password):  # 判断密码是否正确
                #     request.session['username'] = username
                login(request,user)   # 保存状态
                next_url = request.GET.get('next')
                if next_url:
                    # print(next_url)
                    return redirect(next_url)
                else:
                    return redirect(reverse('home'))
                # else:
                #     return render(request,'user_login/login.html',
                #                   {'error':form.errors})
            else:
                return redirect(reverse('register'))
        else:
            return redirect(reverse('login_test'))
def logout_test(request):
    # request.session.flush()
    logout(request)
    return redirect(reverse('home'))



def register(request):
    if request.method == 'GET':
        form = RegisterFrom()
        return render(request,'user_login/register.html',
                      context={'form':form})
    elif request.method == 'POST':
        form = RegisterFrom(request.POST)
        if form.is_valid():
            # 获取前端传来数据
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            password_repeat = form.cleaned_data.get('password_repeat')
            email = form.cleaned_data.get('email')
            # 判断密码
            if password == password_repeat:
                User.objects.create_user(username=username,
                                         password=password,
                                         email=email)
            #     password = make_password(password)  # 加密
            #     存入数据库
            #     UserModel.objects.get_or_create(username=username,password=password,email=email)
                return redirect(reverse('login_test'))
            else:
                return redirect(reverse('register'))
        else:
            print(form.errors)
            return redirect(reverse('register'))

#
#
# def page_error(request):
#     return render(request, '500.html')
#
#
# def permission_denied(request):
#     return render(request, '403.html')
from django.http import HttpResponse
def auth_test(request):
    # xiaoming = User.objects.filter(username='xiaoming').first()
    # # xiaopo.set_password('qwe123')
    add_blog = Permission.objects.filter(codename='add_blogmodel').first()
    # xiaoming.user_permissions.add(add_blog)
    # 组操作
    # Group.objects.create(name='add_blog_group')
    # 给组加权限
    g1 = Group.objects.filter(name='add_blog_group').first()
    # g1.permissions.add(add_blog)
    budong = User.objects.filter(username='budong').first()
    g1.user_set.add(budong)

    return HttpResponse('xxxxxx')




















def page_not_found(request,**kwargs):
    return render(request,'book/404_test.html',status=404)


def page_error(request):
    return render(request,'book/500_test.html',status=500)