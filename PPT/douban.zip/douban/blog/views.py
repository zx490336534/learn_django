from django.shortcuts import render,redirect,reverse
from django.http import HttpResponse
# Create your views here.
from .models import BlogModel
from django.contrib.auth.decorators import login_required,permission_required

@login_required
def index(request):
    return  render(request,'blog/demo_index.html')

@permission_required('blog.add_blogmodel')
def add(request):
    if request.method == 'GET':
        return render(request,'blog/demo_add.html')
    elif request.method == 'POST':
        # print(request.POST)
        title = request.POST.get('title')
        content = request.POST.get('content')
        # print(title,content)
        blog = BlogModel(title=title,content=content)
        blog.save()
        return redirect(reverse('blog_add'))

def list(request):
    blog_list = BlogModel.objects.all()
    return render(request,'blog/demo_list.html',
                  context={'blog_list':blog_list})

def detail(request,blog_id):
    blog = BlogModel.objects.get(id=blog_id)
    return render(request,'blog/demo_detail.html',
                  context={'blog':blog})

# 作业题
def edit(request,blog_id):
    blog = BlogModel.objects.filter(id=blog_id)[0]
    if request.method == 'POST':
        if blog:
            title = request.POST.get('title')
            content = request.POST.get('content')
            blog.title = title
            blog.content = content
            blog.save()
    return render(request, 'blog/demo_edit.html',
                  context={'blog': blog})




def delete(request,blog_id):
    blog = BlogModel.objects.get(id=blog_id)
    if blog:
        blog.delete()
        return redirect(reverse('blog_list'))
    else:
        return HttpResponse('没有这篇博客')

