from django.apps import AppConfig


class GetPostConfig(AppConfig):
    name = 'get_post'
