from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.

def post_test(request):
    if request.method == 'GET':
        return render(request,'get_post/get_post_test.html')
    elif request.method == 'POST':
        a = request.POST.get('a')
        b = request.POST.get('b')
        x = a+b
        return HttpResponse(x)

def get_test(request):
    print(request.GET)
    # a = request.GET.get('a')
    # b = request.GET.get('b')
    a = request.GET.getlist('a')
    print(a)
    return render(request, 'get_post/get_post_test.html')

import os
from douban.settings import MEDIA_ROOT
def upload_test(request):
    if request.method == 'GET':
        return render(request,'get_post/upload_file.html')
    elif request.method == 'POST':
        f = request.FILES.get('file')
        # print(f.name)
        f_name = os.path.join(MEDIA_ROOT,f.name)
        with open(f_name,'wb') as ff:
            for c in f.chunks():
                ff.write(c)
        return HttpResponse('XXXX')

def response_test(request):
    rs = HttpResponse('哈哈哈哈哈')
    # rs.content
    return rs
import datetime
def set_ck(request):
    response = HttpResponse('设置cookie')
    # response.set_cookie('name','taka')   # 默认浏览关闭过期
    # response.set_cookie('name','taka',max_age=200)  # 多少秒
    # response.set_cookie('name','taka',expires=datetime.datetime(2018,11,20))  #
    return response

def get_ck(request):
    cookie = request.COOKIES
    print(cookie.get('name'))
    return HttpResponse('获取cookie')

def delete_ck(request):
    rs = HttpResponse('删除cookie')
    rs.delete_cookie('name')
    return rs








