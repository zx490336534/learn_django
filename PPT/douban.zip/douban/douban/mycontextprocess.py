from form_test.models import UserModel


def myuser(request):
    name = request.session.get('username', '游客')
    user = UserModel.objects.filter(username=name).first()
    if user:
        return {'myuser1':user.username}
    else:
        return {}